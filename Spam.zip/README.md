# IIIC-GenAI
Internship 10.06.2024 to 22.06.2024
